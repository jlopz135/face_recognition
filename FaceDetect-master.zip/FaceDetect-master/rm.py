import shutil
import os

# path = os.getcwd() + "/TestImage/"
# print(path)

# try:
#     shutil.rmtree(path)

# except OSError as error:
#     print(error)

path = os.getcwd() + "/TestImage/"
print(path)
isExist = os.path.exists(path)
if isExist:
    print("Exists...")
    files = os.listdir(path)
    print(files)
    for file in files:
        if file == '.DS_Store':
            continue
        print("File: " + file)
        shutil.rmtree(path+file)

else:
    print("File Doesn't Exist...")
    try:
        os.mkdir(path)
        print("Now It Exists...")
    except OSError as error:
        print("Path: "+ path+ "\nExists...")