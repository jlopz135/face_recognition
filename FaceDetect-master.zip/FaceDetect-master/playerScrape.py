import requests
from bs4 import BeautifulSoup as BS

def player_goals(name):
  r = requests.get('https://www.foxsports.com/soccer/fifa-world-cup-men/stats?category=standard&sort=g&season=2022&sortOrder=desc&groupId=12')
  soup = BS(r.text, 'html.parser')

  y = soup.select('table > tbody > tr')
  all_scorers = {}

  for x in range(len(y)):
      # Since y is an array of the TR's grab each row 
      i = y[x]

      # Get the first TD in each TR which is the player name
      player = i.find_all('td')[1].get_text()
      # Data Clean Up
      player = player.strip()
      size = len(player)
      players = player[:size-10]
      
      # Getting number of goals per player
      goal_raw = i.find_all('td')[5].get_text()
      goals = goal_raw.strip()

      # Making Dict with players and goals associated
      all_scorers[players] = goals 
 
  flag = True
  for k,v in all_scorers.items():

    if name == k:
      print("Name: ", k, "\nGoals: ", v)
      flag = False
      continue
  if flag == True:
    print("Player Not In Top 25 Scorers in the World Cup")

player_goals('Richarlison') 
      
