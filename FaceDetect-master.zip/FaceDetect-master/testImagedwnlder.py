import requests
from bs4 import BeautifulSoup as BS
import os
import shutil

all_scorers = {}

#wipe previous image data
path = os.getcwd() + "/TestImage/"
print("Working In: " + path)
isExist = os.path.exists(path)
if isExist:
    print("Wiping Existing Folder (Cleansing Data)...")
    files = os.listdir(path)
    #print(files)
    for file in files:
        if file == '.DS_Store':
            continue
        #print("File: " + file)
        shutil.rmtree(path+file)

else:
    print("File Doesn't Exist...")
    try:
        os.mkdir(path)
        print("Now It Exists...")
    except OSError as error:
        print("Path: "+ path+ "\nExists...")

def player_goals():
    print("Gathering Player Information...")
    r = requests.get('https://www.foxsports.com/soccer/fifa-world-cup-men/stats?category=standard&sort=g&season=2022&sortOrder=desc&groupId=12')
    soup = BS(r.text, 'html.parser')

    y = soup.select('table > tbody > tr')

    for x in range(len(y)):
        # Since y is an array of the TR's grab each row 
        i = y[x]

        # Get the first TD in each TR which is the player name
        player = i.find_all('td')[1].get_text()
        # Data Clean Up
        player = player.strip()
        size = len(player)
        players = player[:size-10]
        
        # Getting number of goals per player
        goal_raw = i.find_all('td')[5].get_text()
        goals = goal_raw.strip()

        # Making Dict with players and goals associated
        all_scorers[players] = goals 

def check_goals(name):
    flag = True

    for k,v in all_scorers.items():
        if name == k:
            print("Name: ", k, "\nGoals: ", v)
            flag = False
            continue
    if flag == True:
            print("Player Not In Top 25 Scorers in the World Cup")

player_goals()
#for k,v in all_scorers.items():
 #   check_goals(k)
# implement function call case where empty to populate then to check the name

print("Downloading Images Now...")

#trying to populate folders with images to train 
url = ''
val = ''
for k,v in all_scorers.items():
    #print("Here: ", k)

    # Creating URL to search the web for images
    index = k.find('.')
    if index == 1:
        x = k.replace(". ", "+")
        x = x.replace(" ", "+")
        url = 'https://www.google.com/search?q='+x+'+headshot&sxsrf=ALiCzsZJQ2tEXzAOzCIK63Sdsv9N3F3mdw:1670128278894&source=lnms&tbm=isch&sa=X&ved=2ahUKEwi4vqvWkN_7AhXiD1kFHajMDMIQ_AUoAXoECAMQAw&biw=1234&bih=974&dpr=1'
        #print(url)
        size = len(k)
        val = k[3:]

        path = os.getcwd() + "/TestImage/" +val+ "/"
        
        try:
            os.mkdir(path)
        except OSError as error:
            print("Path: "+ path+ "\nExists...")

        res = requests.get(url)
        soup = BS(res.text, 'html.parser')

        mydivs = soup.find_all(class_='bRMDJf')
        results = soup.find_all('div', attrs={"class":""})

        s = soup.find_all('img', attrs={"class":"yWs4tf"})
        #print(len(s))
        count = 0
        x = [None] * len(s)
        for v in s:
            x[count] = v['src']

            url = x[count]
            img_data = requests.get(url).content
            
            inp = 'TestImage/'+ val +'/img_'+ str(count) +'.jpg'
            #print(inp)
            with open(inp, 'wb') as handler:
                handler.write(img_data)

            #print(count, x[count])
            count += 1


    else:
        url = 'https://www.google.com/search?q='+ k + '+headshot&sxsrf=ALiCzsZJQ2tEXzAOzCIK63Sdsv9N3F3mdw:1670128278894&source=lnms&tbm=isch&sa=X&ved=2ahUKEwi4vqvWkN_7AhXiD1kFHajMDMIQ_AUoAXoECAMQAw&biw=1234&bih=974&dpr=1'
        val = k

        path = os.getcwd() + "/TestImage/" +val+ "/"
        
        try:
            os.mkdir(path)
        except OSError as error:
            print("Path: "+ path+ "\nExists...")

        res = requests.get(url)
        soup = BS(res.text, 'html.parser')

        mydivs = soup.find_all(class_='bRMDJf')
        results = soup.find_all('div', attrs={"class":""})

        s = soup.find_all('img', attrs={"class":"yWs4tf"})
        
        count = 0
        x = [None] * len(s)
        for v in s:
            x[count] = v['src']

            url = x[count]
            img_data = requests.get(url).content
            inp = 'TestImage/'+ val +'/img_'+ str(count) +'.jpg'
            #print(inp)
            with open(inp, 'wb') as handler:
                handler.write(img_data)

            #print(count, x[count])
            count += 1
        


#rg_i
print("Done Collecting Images...")