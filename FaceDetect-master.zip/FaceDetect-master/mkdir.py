import os

path = os.getcwd() + "/TestImage/Messi/"
print(path)

try:
    os.mkdir(path)

except OSError as error:
    print(error)