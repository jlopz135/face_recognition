import requests
from bs4 import BeautifulSoup as BS
import os

r = requests.get('https://www.google.com/search?q=messi+face&sxsrf=ALiCzsZJQ2tEXzAOzCIK63Sdsv9N3F3mdw:1670128278894&source=lnms&tbm=isch&sa=X&ved=2ahUKEwi4vqvWkN_7AhXiD1kFHajMDMIQ_AUoAXoECAMQAw&biw=1234&bih=974&dpr=1')
soup = BS(r.text, 'html.parser')

mydivs = soup.find_all(class_='bRMDJf')
results = soup.find_all('div', attrs={"class":""})
#print(soup.prettify())
s = soup.find_all('img', attrs={"class":"yWs4tf"})

print(len(s))
count = 0
x = [None] * len(s)

# Create folders for each player
path = os.getcwd() + "/TestImage/Messi/"
print(path)

try:
    os.mkdir(path)
except OSError as error:
    print()

for v in s:
  x[count] = v['src']

  url = x[count]
  img_data = requests.get(url).content
  inp = 'TestImage/Messi/Messi_'+ str(count) +'.jpg'
  print(inp)
  f = open(inp, 'wb')
  with f as handler:
      handler.write(img_data)

  print(count, x[count])
  count += 1
  
